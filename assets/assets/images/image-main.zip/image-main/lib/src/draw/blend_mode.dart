enum BlendMode {
  direct,
  alpha,
  lighten,
  screen,
  dodge,
  addition,
  darken,
  multiply,
  burn,
  overlay,
  softLight,
  hardLight,
  difference,
  subtract,
  divide
}
