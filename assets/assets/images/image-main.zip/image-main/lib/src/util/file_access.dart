export '_file_access.dart'
    if (dart.library.io) '_file_access_io.dart'
    if (dart.library.js) '_file_access_html.dart';
