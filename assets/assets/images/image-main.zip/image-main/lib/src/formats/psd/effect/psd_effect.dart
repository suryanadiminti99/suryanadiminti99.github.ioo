class PsdEffect {
  int? version;
  bool? enabled;
}
