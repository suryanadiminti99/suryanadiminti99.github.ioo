class JpegAdobe {
  int? version;
  int? flags0;
  int? flags1;
  int? transformCode;
}
