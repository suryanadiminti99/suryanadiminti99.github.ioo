import 'psd_effect.dart';

class PsdInnerGlowEffect extends PsdEffect {
  int? blur;
  int? intensity;
  List<int>? color;
  String? blendMode;
  int? opacity;
  bool? invert;
  List<int>? nativeColor;
}
