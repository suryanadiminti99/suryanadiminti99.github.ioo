import 'psd_effect.dart';

class PsdOuterGlowEffect extends PsdEffect {
  int? blur;
  int? intensity;
  List<int>? color;
  String? blendMode;
  int? opacity;
  List<int>? nativeColor;
}
